/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

//import java.util.*;
import javax.ws.rs.core.*;
import javax.ws.rs.*;

/**
 * REST Web Service
 *
 * @author marianasic
 */

//path que define como es que se va a acceder al recurso:
@Path("/usuarios")
public class UsuariosResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of UsuariosResource
     */
    public UsuariosResource() {
    }

    
    /**
     * 
     * @param a
     * @return 
     */
    
    @Path("/login")
    @POST
    @Consumes("application/json")
    @Produces("application/json")
    public String postJson(Admin a){
        String respuesta = "";
        
        if(a.user.equals("admin") && a.pass.equals("201504051")){
            respuesta+="true";
        }else{
            respuesta+="false";
        }
        
        return respuesta;
    }
    
}